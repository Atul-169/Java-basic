public class FriendTask implements Runnable {

    private final String name;
    private final Action[] actions;
    private final int[] stock;

    public FriendTask(String name, Action[] actions, int[] stock) {
        this.name = name;
        this.actions = actions;
        this.stock = stock;
    }

    @Override
    public void run() {
        for (Action a : actions) {
            if (a.type == 'a') {
                synchronized (stock) {
                    stock[a.item]++;
                }
                System.out.println(name + " added item " + a.item);
            } else {
                synchronized (stock) {
                    stock[a.item]--;
                }
                System.out.println(name + " removed item " + a.item);
            }
        }
    }
}
import java.util.Scanner;

public class KitchenInventory {

    public static void main(String[] args) throws InterruptedException {
        Scanner sc = new Scanner(System.in);

        int N = sc.nextInt(); // number of friends (threads)
        int M = sc.nextInt(); // number of items

        int[] stock = new int[M];
        Thread[] threads = new Thread[N];

        for (int i = 0; i < N; i++) {
            int k = sc.nextInt(); // number of actions

            Action[] acts = new Action[k];

            for (int j = 0; j < k; j++) {
                char type = sc.next().charAt(0);
                int item = sc.nextInt();
                acts[j] = new Action(type, item);
            }

            String name = "Friend-" + (i + 1);
            threads[i] = new Thread(new FriendTask(name, acts, stock));
        }

        // Start all threads
        for (Thread t : threads) {
            t.start();
        }

        // Wait for all threads to finish
        for (Thread t : threads) {
            t.join();
        }

        // Print final inventory
        System.out.println("\nFinal inventory status:");
        for (int i = 0; i < M; i++) {
            if (i > 0) System.out.print(" ");
            System.out.print(stock[i]);
        }
    }
}
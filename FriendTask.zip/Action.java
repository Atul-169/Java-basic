public class Action {
    char type;
    int item;

    public Action(char type, int item) {
        this.type = type;
        this.item = item;
    }
}